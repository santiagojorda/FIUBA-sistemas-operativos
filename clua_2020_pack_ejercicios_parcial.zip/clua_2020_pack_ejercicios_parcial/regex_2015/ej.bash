nro_factura=$1
facturas='FacturasElectronicas.dat'
boletos='BoletosBancarios.dat'

# Número de factura es única:
export cod_boleto=$(grep -E "^${nro_factura},[^,]*,[^,]*,[^,]*,[^,]*$" $facturas | sed -E 's/^[^,]*,[^,]*,([^,]*),[^,]*,[^,]*$/\1/g')

export url_factura=$(grep -E "^${nro_factura},[^,]*,[^,]*,[^,]*,[^,]*$" $facturas | sed -E 's/^[^,]*,[^,]*,[^,]*,([^,]*),[^,]*$/\1/g')              
# Para un boleto, hay muchas cuotas
grep -E "^${cod_boleto},[^,]*,[^,]*,[^,]*,[^,]*$" $boletos | sed -E 's/^[^,]*,([^,]*),[^,]*,[^,]*,([^,]*)$/echo "${url_factura};\1;\2"/ge'
