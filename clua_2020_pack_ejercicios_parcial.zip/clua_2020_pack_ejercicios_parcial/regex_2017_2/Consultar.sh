AVE=$1
PAQUETES='CatalogoDePaquetes.dat'
MSJ="No hay disponibilidad de paquete comercial para el ave ${AVE}"

# Filtro las líneas con el nombre científico del ave
# Me quedo con la "columna" de interés
# Eso se guarda en una arreglo
arr[0]=$( grep -E "^[^;]*;[^;]*;${AVE};[^;]*;[^;]*;[^;]*;[^;]*;$" $PAQUETES | sed -E 's/^[^;]*;([^;]*);[^;]*;[^;]*;[^;]*;[^;]*;[^;]*;$/\1/g' )

arr[${#arr[0]}]=${MSJ}

# Se imprime lo guardado en el primer elemento del array
echo ${arr[0]}
