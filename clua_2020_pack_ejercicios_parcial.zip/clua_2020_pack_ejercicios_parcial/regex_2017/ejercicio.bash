DISPS='disponibilidad.dat'
HUES=$(echo $1 | sed -E 's/^([^,]+),[^,]+$/\1/g')
ESTR=$(echo $1 | sed -E 's/^[^,]+,([^,]+)$/\1/g')
FECHA='29/03/2018'
ESTADO='DISP'

grep -E "^[^;]+;[^;]+;${ESTR};[^;]+;${HUES};${FECHA};${ESTADO}$" $DISPS | wc -l
