precios='ListasDePrecios.dat'
localidad=$( echo $1 | sed -E 's/^[^\|]*\|[^\|]*\|[^\|]*\|([^\|]*)\|$/\1/g' )

id_lista=$( grep -E "^[^;]*;[^;]*;[^;]*;${localidad};[^;]*;$" $precios | sed -E 's/^([^;]*);[^;]*;[^;]*;[^;]*;[^;]*;$/\1/g' )

echo "Lista de Precios: ${id_lista}"

# Se sabe que el archivo de id_lista va a existir
grep -E "^[^;]*;[^;]*;[^;]*;[^;]*;[^;]*;$" $id_lista | sed -E 's/^([^;]*);[^;]*;([^;]*);[^;]*;[^;]*;$/echo \1 "+" \2/ge'
