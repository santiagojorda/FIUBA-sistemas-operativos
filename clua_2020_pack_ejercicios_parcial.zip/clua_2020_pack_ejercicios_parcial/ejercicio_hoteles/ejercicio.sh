# cantidad de habitaciones disponibles
huespedes=$(echo $1 | sed 's/,.*$//g')
estrellas=$(echo $1 | sed 's/^.*,//g')
archivo='disponibilidad.dat'

grep "^[^-]*-[^-]*-${estrellas}-[^-]*-${huespedes}-17/02/2013-DISP$" $archivo | wc -l
