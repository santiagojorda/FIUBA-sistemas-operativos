export partidos="Match.Master"
export paises="Country.List"
export pais=$1
export condicion=$2

# Obtengo el ID del país
id_pais=$( grep -E "^[^,]*,${pais},[^,]*$" $paises | sed -E 's/^([^,]*),[^,]*,[^,]*$/\1/g' )

# Arreglos asociativos auxiliares según el caso de local o visitante
declare -A filtro palab1 palab2 palab3 palab4
filtro["LOCAL"]="^[^;]*;[^;]*;${id_pais};[^;]*;[^;]*;[^;]*;[^;]*;[^;]*;[^;]*$"
filtro["VISITANTE"]="^[^;]*;[^;]*;[^;]*;${id_pais};[^;]*;[^;]*;[^;]*;[^;]*;[^;]*$"
palab1["LOCAL"]="GANO PENALES el"
palab1["VISITANTE"]="PERDIO PENALES el"
palab2["LOCAL"]="PERDIO PENALES el"
palab2["VISITANTE"]="GANO PENALES el"
palab3["LOCAL"]="GANO el"
palab3["VISITANTE"]="PERDIO el"
palab4["LOCAL"]="PERDIO el"
palab4["VISITANTE"]="GANO el"

# Filtro partidos dependiendo si es local o visitante
# Aplico el formato pedido
# Quito los paréntesis si no hubo penales
# Cambio letras (Ej: PXX) por palabras (Ej: PERDIO) según si es local o no
grep -E ${filtro[$condicion]} $partidos | 
sed -E "s/^[^;]*;([^;]*);[^;]*;[^;]*;(..)(..);(..)(..);([^;]*);[^;]*;[^;]*$/echo \6 el \1 \2 a \4 '('\3 a \5')'/ge" | 
sed -E "s/\(00 a 00\)$//g" | 
sed -E "s/^WP.. el/${palab1[$condicion]}/g" | 
sed -E "s/^LP.. el/${palab2[$condicion]}/g" |
sed -E "s/^W.. el/${palab3[$condicion]}/g" |
sed -E "s/^L.. el/${palab4[$condicion]}/g" 
