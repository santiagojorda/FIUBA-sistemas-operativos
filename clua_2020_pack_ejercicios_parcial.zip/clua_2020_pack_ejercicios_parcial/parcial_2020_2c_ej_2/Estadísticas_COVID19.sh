fjalfgfkajsd fads adsf ;fdfd;21079;fdjkfjkd;fjalfjalds;Sudáfrica;fadfa;89.332
fjaldfka fads adsf ;fdfd;12717;fdjkfjkd; dsd ;Ucrania;fadfa;89.332
fjaldfkajsd fads adsf ;fdfd;279323;fdjkfjkd;fjalfjalds;Estados Unidos;fadfa;89.332;hola
fjalfdfad;fdfd;138628;fdjkfjkd;fjalfjalds;India;fadfa;89.332;hola;buen
fjaldfkajsd fads adsf ;fdfd;174515;fdjkfjkd;f;Brasil;fadfa;89.332;hola;buen;dia
fjaldfkajsd fads adsf ;fdfd;36031;fdjkfjkd;fjalfjalds;Peru;fadfa;89.332;a
fjaldfkajsd fads adsf ;fdfd;41053;df;fjalfjalds;Rusia;fadfa;89.332;a;b;c;d;e;f;g
fjaldfka fads adsf ;fdfd;444;fdjkfjkd; dsd ;Inexistente;fadfa;44.2
fjaldfk adsf ;fdfd;53816;fdjkfjkd;fjalfjalds;Francia;fadfa;89.332
