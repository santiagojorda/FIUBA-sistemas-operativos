codigo=$1
sistema=10

a1=$(echo $codigo | grep -E '^A$')
a2=$(echo $codigo | grep -E '^[^A]$')
a3=$(echo $codigo | grep -E '^AA$')
a4=$(echo $codigo | grep -E '^A[B-F]$')
a5=$(echo $codigo | grep -E '^A[G-Z]$')
a6=$(echo $codigo | grep -E '^[B-Z][A-Z]$')
a7=$(echo $codigo | grep -E '^...$')
a8=$(echo $codigo | grep -E '^....$')

## A
aux1=$( echo $(( $( echo $a1 | wc -m ) > 1 )) )
posibles[${aux1}]='SIN_REACTOR'

## Solo hay un caracter que no es A
aux2=$( echo $(( $( echo $a2 | wc -m ) > 1 )) )
posibles[${aux2}]='NORMAL'

# AA
aux3=$( echo $(( $( echo $a3 | wc -m ) > 1 )) )
posibles[${aux3}]='NORMAL'

# AB - AF
aux4=$( echo $(( $( echo $a4 | wc -m ) > 1 )) )
posibles[${aux4}]='CALIENTE'

# AG - AZ
aux5=$( echo $(( $( echo $a5 | wc -m ) > 1 )) )
posibles[${aux5}]='SOBRECALENTADO'

# BA - ZZ
aux6=$( echo $(( $( echo $a6 | wc -m ) > 1 )) )
posibles[${aux6}]='SOBRECALENTADO'

# Hay un tercer caracter
aux7=$( echo $(( $( echo $a7 | wc -m ) > 1 )) )
posibles[${aux7}]='SOBRECALENTADO'

# Hay 4 caracteres
aux8=$( echo $(( $( echo $a8 | wc -m ) > 1 )) )
posibles[${aux8}]='SOBRECALENTADO'

#SendAlarm.sh ${posibles[1]} $sistema
echo ${posibles[1]} $sistema
